import React from 'react';
import Quiz from './components/Quiz';

function App() {
  return (
    <div className="bg-gray-100 min-h-screen flex flex-col justify-center items-center">
      <header className="bg-blue-500 text-white py-4 w-full text-center">
        <h1 className="text-4xl font-bold">CSS Selector Specificity Quiz</h1>
      </header>
      <main className="py-6 flex-grow container mx-auto">
        <Quiz />
      </main>
    
    </div>
  );
}

export default App;
