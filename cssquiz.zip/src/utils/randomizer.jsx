const tagNames = ['div', 'span', 'p', 'a', 'button', 'img', 'ul', 'li'];
const pseudoClasses = ['hover', 'active', 'focus'];
const pseudoElements = ['before', 'after'];
const attributeSelectors = ['disabled', 'checked'];
const idClassNames = ['main', 'header', 'footer', 'sidebar', 'content', 'nav', 'title', 'text'];
const combinators = [' ', '>', '+', '~'];

function getRandomItem(array) {
  return array[Math.floor(Math.random() * array.length)];
}

function getRandomSelector() {
  let selector = '';
  let prevSelector = '';

  for (let i = 0; i < 16; i++) {
    if (Math.random() < 0.5) continue;

    const category = Math.floor(Math.random() * 5);
    let currentSelector = '';

    switch (category) {
      case 0:
        currentSelector = getRandomItem(tagNames);
        break;
      case 1:
        currentSelector = '.' + getRandomItem(idClassNames);
        break;
      case 2:
        currentSelector = '#' + getRandomItem(idClassNames);
        break;
      case 3:
        currentSelector = ':' + getRandomItem(pseudoClasses);
        break;
      case 4:
        currentSelector = '::' + getRandomItem(pseudoElements);
        break;
      case 5:
        currentSelector = '[' + getRandomItem(attributeSelectors) + ']';
        break;
    }

    if (prevSelector && !prevSelector.endsWith(' ') && !currentSelector.startsWith(':')) {
      selector += getRandomItem(combinators);
    }

    selector += currentSelector;
    prevSelector = currentSelector;
  }

  return selector;
}

export default getRandomSelector;