import React from 'react';

const Selector = ({ selector }) => {
  return (
    <div className="selector">    
      <span className="selector-item"  >{selector}</span> 
    </div>
  );
};

export default Selector;