import React, { useState } from 'react';
import Selector from './Selector';
import Randomizer from './Randomizer';
import getRandomSelector from '../utils/randomizer';

const Quiz = () => {
  const [selector, setSelector] = useState(getRandomSelector());
  const [guess, setGuess] = useState({ a: '', b: '', c: '' });
  const [feedback, setFeedback] = useState({ a: '', b: '', c: '' });

  const handleRandomize = () => {
    setSelector(getRandomSelector());
    setGuess({ a: '', b: '', c: '' });
    setFeedback({ a: '', b: '', c: '' });
  };

  const handleGuessChange = (e) => {
    const { name, value } = e.target;
    setGuess((prevGuess) => ({ ...prevGuess, [name]: value }));
  };

 
  const calculateSpecificity = (selector) => {
    const idRegex = /#[\w-]+/g; // Match ID selectors
    const classAttrPseudoRegex = /(\.[\w-]+|\[[^\]]+\]|:[\w-]+)/g; // Match class selectors, attribute selectors, and pseudo-classes
    const typePseudoElementRegex = /([\w-]+|\:\:[\w-]+)/g; // Match type selectors and pseudo-elements
  
    const idMatches = selector.match(idRegex) || [];
    const classAttrPseudoMatches = selector.match(classAttrPseudoRegex) || [];
    const typePseudoElementMatches = selector.match(typePseudoElementRegex) || [];
  
    const idCount = idMatches.length;
    const classAttrPseudoCount = classAttrPseudoMatches.length;
    const typePseudoElementCount = typePseudoElementMatches.length;
    
    console.log(idCount, classAttrPseudoCount, typePseudoElementCount)
    return [idCount, classAttrPseudoCount, typePseudoElementCount];
  };
  

  const handleSubmitGuess = () => {
    const [idCount, classCount, tagCount] = calculateSpecificity(selector);
    const aIsCorrect = parseInt(guess.a) === idCount;
    const bIsCorrect = parseInt(guess.b) === classCount;
    const cIsCorrect = parseInt(guess.c) === tagCount;

    setFeedback({
      a: aIsCorrect ? 'correct' : 'incorrect',
      b: bIsCorrect ? 'correct' : 'incorrect',
      c: cIsCorrect ? 'correct' : 'incorrect',
    });
  };

  return (
    <div className="min-h-screen bg-gray-100 flex flex-col items-center justify-center">
      <Randomizer onRandomize={handleRandomize} />

      <div className="mt-4 p-4 border rounded-lg bg-white shadow-lg space-y-4">
      <p className="text-xl text-gray-700 font-semibold">
        Guess the specificity of the following selector:
      </p>
        <Selector selector={selector}  />

        <div className="flex space-x-4">
          <input
            type="number"
            name="a"
            value={guess.a}
            onChange={handleGuessChange}
            className={`rounded border p-2 ${feedback.a === 'correct' ? 'border-green-500' : 'border-red-500'}`}
          />
          <input
            type="number"
            name="b"
            value={guess.b}
            onChange={handleGuessChange}
            className={`rounded border p-2 ${feedback.b === 'correct' ? 'border-green-500' : 'border-red-500'}`}
          />
          <input
            type="number"
            name="c"
            value={guess.c}
            onChange={handleGuessChange}
            className={`rounded border p-2 ${feedback.c === 'correct' ? 'border-green-500' : 'border-red-500'}`}
          />
          <button
            onClick={handleSubmitGuess}
            className="px-4 py-2 rounded bg-blue-500 text-white"
          >
            Submit
          </button>
        </div>
      </div>
    </div>
  );
};

export default Quiz;
