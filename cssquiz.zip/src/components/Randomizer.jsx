import React from 'react';

const Randomizer = ({ onRandomize }) => {
  return (
    <button 
      className="px-4 py-2 rounded bg-indigo-500 text-white"
      onClick={onRandomize}
    >
      Randomize!
    </button>
  );
};

export default Randomizer;