# CSS Quiz App

## Installation Steps

- Install nodemodules

```bash
npm install
```

- run the app

```bash
npm run dev
```

- view in browser
```bash

http://localhost:5173
```